## Downloed Proxmox and flash it into bootable USB

wget https://enterprise.proxmox.com/iso/proxmox-ve_8.1-1.iso

